<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 */


/**
 * Dumps a XML Sitemap in 0.9 version style. 
 * 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @author Kevin Papst 
 * @copyright Copyright (C) Kevin Papst
 * @version $Id: sitemap-v09.php,v 1.7 2008/11/30 16:48:45 kpapst Exp $
 * @package bigace.addon
 * @subpackage seo
 */

define('TOPLEVEL_UNIQUE_URL', false);

include_once(dirname(__FILE__) . '/../../system/libs/init_session.inc.php');

import('classes.item.ItemRequest');
import('classes.item.SimpleItemTreeWalker');
import('classes.menu.Menu');
import('classes.language.LanguageEnumeration');

header("Content-type: text/xml");

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

$enum = new LanguageEnumeration();
for($i = 0; $i < $enum->count(); $i++) {
	
	$lang = $enum->next();
	
	$topLevel = new Menu(_BIGACE_TOP_LEVEL, ITEM_LOAD_FULL, $lang->getLanguageID());
	
	// if this menu really exist, display it and its subtree 
	if($topLevel->exists() && !$topLevel->isHidden()) {
		echo "<!-- Language: ".$lang->getLanguageID()." -->\n";
		
		if(TOPLEVEL_UNIQUE_URL) {
			showItemXML($topLevel);
		}
		else {
			$link = LinkHelper::getCMSLinkFromItem($topLevel);
			$link->setUniqueName("/");
			showItemXML($topLevel,$link);
		}
	
		getNavi(_BIGACE_TOP_LEVEL, $lang->getLanguageID(), 10, false);
	}
}

echo "\n".'</urlset>';

function getNavi($id = null, $lang = null, $level = 3, $showHidden = false)
{
	$ir = new ItemRequest(_BIGACE_ITEM_MENU);

	if($showHidden)
		$ir->setFlagToExclude($ir->FLAG_ALL_EXCEPT_TRASH);

	if(!is_null($id))
		$ir->setID($id);
		
	if(!is_null($lang))
		$ir->setLanguageID($lang);
		
	$menu_info = new SimpleItemTreeWalker($ir);
	
	for($i=0; $i < $menu_info->count(); $i++)
	{
		$temp = $menu_info->next();
    	
		showItemXML($temp);
    	 
		if($level > 0)
	    		getNavi($temp->getID(), $lang, ($level-1), $showHidden);
	}
}

function showItemXML($item, $link = null) 
{
	if(is_null($link))
		$link = LinkHelper::getCMSLinkFromItem($item);
?>
  <url>
    <loc><?php echo LinkHelper::getUrlFromCMSLink( $link ); ?></loc>
    <lastmod><?php echo date("Y-m-d", $item->getLastDate()); ?></lastmod>
  </url>
<?php
}

?>